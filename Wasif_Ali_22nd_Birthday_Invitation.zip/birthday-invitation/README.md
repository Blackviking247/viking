# Wasif Ali — 22nd Birthday Invitation

A mobile-first scratch-to-reveal birthday invitation for GitHub Pages.

## Deploy

1. Create/open your GitHub repository.
2. Upload `index.html` to the repository root.
3. Commit the file.
4. Open **Settings → Pages**.
5. Select **Deploy from a branch**, choose `main`, folder `/ (root)`, and save.
6. Open the GitHub Pages URL.

The QR code is generated from `window.location.href`, so it automatically points to the deployed invitation URL.

## Features

- Touch and mouse scratch interaction
- Scratch percentage detection
- Automatic cinematic reveal
- Responsive mobile-first design
- Animated metallic “22”
- Celebration particles
- Dynamic QR code
- Replay button
- Reduced-motion support
- No backend required

The page uses Google Fonts and QRCode.js from CDNs, so an internet connection is required for those external resources.
